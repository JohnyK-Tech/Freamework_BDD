package StepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OrdersSteps {

	@Given("a resistered user exists")
	public void a_resistered_user_exists() {
	  
	}

	@Given("user is on amazon login page")
	public void user_is_on_amazon_login_page() {
	   
	}

	@When("user enters username")
	public void user_enters_username() {
	   
	}

	@When("user enters password")
	public void user_enters_password() {
	  
	}

	@When("user clicks on login button")
	public void user_clicks_on_login_button() {
	    
	}

	@Then("user navigates to order page")
	public void user_navigates_to_order_page() {
	   
	}

	@When("user ckicks on previous orders link")
	public void user_ckicks_on_previous_orders_link() {
	  
	}

	@Then("user checks the previous order details")
	public void user_checks_the_previous_order_details() {
	   
	}

	@When("user clicks on open orders link")
	public void user_clicks_on_open_orders_link() {
	  
	}

	@Then("user checks the open order details")
	public void user_checks_the_open_order_details() {
	   
	}

	@When("user clicks on cancelled orders link")
	public void user_clicks_on_cancelled_orders_link() {
	   
	}

	@Then("user checks the Cancelled order details")
	public void user_checks_the_cancelled_order_details() {
	  
	}
}
